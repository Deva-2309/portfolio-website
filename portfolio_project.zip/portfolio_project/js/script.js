/* ============================================================
   script.js — Core interactions: nav, typing, counters, reveals
   ============================================================ */

/* ── Preloader ── */
window.addEventListener('load', () => {
  setTimeout(() => {
    const loader = document.getElementById('preloader');
    if (loader) loader.classList.add('hidden');
  }, 1900);
});

/* ── Navbar scroll state ── */
const navbar = document.getElementById('navbar');
const backToTop = document.getElementById('back-to-top');

window.addEventListener('scroll', () => {
  if (navbar) {
    navbar.classList.toggle('scrolled', window.scrollY > 20);
  }
  if (backToTop) {
    backToTop.classList.toggle('visible', window.scrollY > 400);
  }
  updateActiveNav();
}, { passive: true });

/* ── Back to top ── */
if (backToTop) {
  backToTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/* ── Mobile menu ── */
const hamburger = document.querySelector('.hamburger');
const mobileMenu = document.querySelector('.mobile-menu');

if (hamburger && mobileMenu) {
  hamburger.addEventListener('click', () => {
    const open = hamburger.classList.toggle('open');
    mobileMenu.classList.toggle('open', open);
    hamburger.setAttribute('aria-expanded', open);
  });

  // Close on link click
  mobileMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      hamburger.classList.remove('open');
      mobileMenu.classList.remove('open');
      hamburger.setAttribute('aria-expanded', false);
    });
  });

  // Close on outside click
  document.addEventListener('click', (e) => {
    if (!hamburger.contains(e.target) && !mobileMenu.contains(e.target)) {
      hamburger.classList.remove('open');
      mobileMenu.classList.remove('open');
    }
  });
}

/* ── Active nav link ── */
function updateActiveNav() {
  const sections = document.querySelectorAll('section[id]');
  const links = document.querySelectorAll('.nav-links a, .mobile-menu a');
  let current = '';

  sections.forEach(sec => {
    if (window.scrollY >= sec.offsetTop - 120) current = sec.id;
  });

  links.forEach(link => {
    link.classList.toggle('active', link.getAttribute('href') === `#${current}`);
  });
}

/* ── Typed.js-style typing effect ── */
function initTyping(el) {
  if (!el) return;
  const words = el.dataset.words ? JSON.parse(el.dataset.words) : ['Developer'];
  let wIdx = 0, cIdx = 0, deleting = false;

  function type() {
    const word = words[wIdx];
    el.textContent = deleting ? word.slice(0, cIdx--) : word.slice(0, cIdx++);

    let delay = deleting ? 60 : 110;
    if (!deleting && cIdx > word.length)   { delay = 2000; deleting = true; }
    if (deleting && cIdx < 0)              { deleting = false; wIdx = (wIdx + 1) % words.length; delay = 400; }
    setTimeout(type, delay);
  }
  type();
}

document.querySelectorAll('[data-typed]').forEach(initTyping);

/* ── Intersection Observer — Reveal ── */
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      const el = entry.target;
      // Stagger children if [data-stagger] on parent
      setTimeout(() => el.classList.add('revealed'), el.dataset.delay || 0);
      revealObserver.unobserve(el);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('[data-reveal]').forEach(el => revealObserver.observe(el));

/* ── Stagger grid reveals ── */
document.querySelectorAll('[data-stagger-grid]').forEach(grid => {
  const items = grid.querySelectorAll('[data-reveal]');
  items.forEach((item, i) => { item.dataset.delay = i * 100; });
});

/* ── Animated counter ── */
function animateCounter(el) {
  const target = parseInt(el.dataset.target, 10);
  const duration = 2000;
  const start = performance.now();

  function tick(now) {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    // Ease out quad
    const eased = 1 - (1 - progress) * (1 - progress);
    el.textContent = Math.round(eased * target) + (el.dataset.suffix || '');
    if (progress < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      animateCounter(entry.target);
      counterObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('[data-target]').forEach(el => counterObserver.observe(el));

/* ── Skill bar animation ── */
const barObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.querySelectorAll('.skill-bar-fill').forEach(fill => {
        fill.style.width = fill.dataset.width;
      });
      barObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.3 });

document.querySelectorAll('.skill-bar-wrap, .skills-section').forEach(el => barObserver.observe(el));

/* ── Skills category filter ── */
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const category = btn.dataset.filter;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    document.querySelectorAll('[data-category]').forEach(card => {
      const show = category === 'all' || card.dataset.category === category;
      card.style.opacity = show ? '1' : '0.2';
      card.style.transform = show ? '' : 'scale(0.95)';
      card.style.pointerEvents = show ? '' : 'none';
    });
  });
});

/* ── FAQ Accordion ── */
document.querySelectorAll('.faq-question').forEach(btn => {
  btn.addEventListener('click', () => {
    const item = btn.closest('.faq-item');
    const isOpen = item.classList.contains('open');

    // Close all
    document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
    // Toggle current
    if (!isOpen) item.classList.add('open');

    btn.setAttribute('aria-expanded', !isOpen);
  });
});

/* ── Contact form ── */
const contactForm = document.getElementById('contact-form');
if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = contactForm.querySelector('[type="submit"]');
    const original = btn.innerHTML;

    // Validate
    const inputs = contactForm.querySelectorAll('[required]');
    let valid = true;
    inputs.forEach(input => {
      const err = input.parentElement.querySelector('.field-error');
      if (!input.value.trim()) {
        valid = false;
        input.classList.add('error');
        if (err) err.style.display = 'block';
      } else {
        input.classList.remove('error');
        if (err) err.style.display = 'none';
      }
    });
    if (!valid) return;

    // Email format check
    const emailInput = contactForm.querySelector('[type="email"]');
    if (emailInput && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailInput.value)) {
      emailInput.classList.add('error');
      showToast('Please enter a valid email address.', 'error');
      return;
    }

    // Simulate send
    btn.innerHTML = '<i class="fa-solid fa-circle-notch animate-spin" aria-hidden="true"></i> Sending…';
    btn.disabled = true;

    await new Promise(r => setTimeout(r, 1800));

    btn.innerHTML = '<i class="fa-solid fa-check" aria-hidden="true"></i> Sent!';
    showToast('Message sent successfully! I\'ll be in touch soon.', 'success');
    contactForm.reset();

    setTimeout(() => {
      btn.innerHTML = original;
      btn.disabled = false;
    }, 3000);
  });

  // Live validation clear
  contactForm.querySelectorAll('input, textarea').forEach(input => {
    input.addEventListener('input', () => {
      input.classList.remove('error');
      const err = input.parentElement.querySelector('.field-error');
      if (err) err.style.display = 'none';
    });
  });
}

/* ── Toast notification ── */
function showToast(message, type = 'info') {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.className = `toast show ${type}`;
  setTimeout(() => toast.classList.remove('show'), 4000);
}
window.showToast = showToast;

/* ── Cursor glow (desktop only) ── */
if (window.matchMedia('(pointer: fine)').matches) {
  const glow = document.querySelector('.cursor-glow');
  if (glow) {
    document.addEventListener('mousemove', e => {
      glow.style.left = e.clientX + 'px';
      glow.style.top  = e.clientY + 'px';
    }, { passive: true });
  }
}

/* ── Smooth anchor scrolling ── */
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});
