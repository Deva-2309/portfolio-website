/* ============================================================
   theme.js — Dark/Light mode with localStorage persistence
   ============================================================ */

(function () {
  const STORAGE_KEY = 'portfolio-theme';
  const ICONS = { dark: 'fa-moon', light: 'fa-sun' };

  /* Apply theme immediately (before paint, avoids flash) */
  const saved = localStorage.getItem(STORAGE_KEY);
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const initial = saved || (prefersDark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', initial);

  /* Sync toggle icon after DOM ready */
  document.addEventListener('DOMContentLoaded', () => {
    const toggles = document.querySelectorAll('.theme-toggle');
    function updateToggle(theme) {
      toggles.forEach(btn => {
        const icon = btn.querySelector('i');
        if (!icon) return;
        icon.className = `fa-solid ${ICONS[theme]}`;
        btn.setAttribute('aria-label', `Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`);
        btn.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
      });
    }

    updateToggle(initial);

    toggles.forEach(btn => {
      btn.addEventListener('click', () => {
        const current = document.documentElement.getAttribute('data-theme');
        const next = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem(STORAGE_KEY, next);
        updateToggle(next);
      });
    });
  });

  /* Respect OS changes if no saved preference */
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
    if (!localStorage.getItem(STORAGE_KEY)) {
      const theme = e.matches ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', theme);
    }
  });
})();
